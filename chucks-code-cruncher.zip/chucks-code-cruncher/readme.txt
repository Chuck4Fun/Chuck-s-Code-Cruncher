=== Chuck's Code Cruncher ===
Contributors: Chuck
Tags: malware, security, scan, wordpress
Requires at least: 5.0
Tested up to: 6.5
Stable tag: 1.0
License: GPLv2 or later

A lightweight WordPress plugin to scan for malicious filenames and code snippets.

== Description ==
Chuck's Code Cruncher allows WordPress admins to scan through all site files to detect suspicious filenames and code snippets that could indicate a hack or malware infection.

Features:
* Input filenames or code snippets you want to search for.
* Recursively scans all WordPress files and folders.
* Displays results in a clean, readable table.
* Lightweight, no bloat.

== Installation ==
1. Upload the plugin files to the `/wp-content/plugins/chucks-code-cruncher/` directory, or install through the WordPress plugins screen.
2. Activate the plugin through the 'Plugins' screen in WordPress.
3. Access "Code Cruncher" from the admin menu.

== Frequently Asked Questions ==
= Will this remove malware? =
No, this plugin is detection-only. It will help you find suspicious code or filenames.

= Can I export results? =
Currently results are shown in the admin area only.

== Changelog ==
= 1.0 =
* Initial release with filename + snippet scanning.
