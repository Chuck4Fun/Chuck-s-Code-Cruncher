<?php
/*
Plugin Name: Chuck's Code Cruncher
Description: Scan WordPress files for malicious code snippets or filenames.
Version: 1.0
Author: Chuck
*/

if ( ! defined( 'ABSPATH' ) ) exit;

class ChucksCodeCruncher {
    public function __construct() {
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_assets'));
    }

    public function add_admin_menu() {
        add_menu_page(
            "Chuck's Code Cruncher",
            "Code Cruncher",
            'manage_options',
            'chucks-code-cruncher',
            array($this, 'settings_page'),
            'dashicons-search',
            100
        );
    }

    public function enqueue_assets($hook) {
        if ($hook !== 'toplevel_page_chucks-code-cruncher') return;
        wp_enqueue_style('ccc-admin', plugin_dir_url(__FILE__) . 'assets/admin.css');
    }

    public function settings_page() {
        echo '<div class="wrap"><h1><img src="' . plugin_dir_url(__FILE__) . 'assets/logo.png" height="32"> Chuck's Code Cruncher</h1>';
        echo '<div class="ccc-container">';
        echo '<form method="post" class="ccc-form">';
        echo '<label for="ccc-filenames">Suspicious Filenames (one per line)</label>';
        echo '<textarea name="ccc-filenames" id="ccc-filenames"></textarea>';
        echo '<label for="ccc-snippets">Code Snippets (one per line)</label>';
        echo '<textarea name="ccc-snippets" id="ccc-snippets"></textarea>';
        submit_button("Run Scan");
        echo '</form>';

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $filenames = array_filter(array_map('trim', explode("\n", $_POST['ccc-filenames'])));
            $snippets = array_filter(array_map('trim', explode("\n", $_POST['ccc-snippets'])));
            $results = $this->scan_files(ABSPATH, $filenames, $snippets);

            echo '<div class="ccc-results"><h2>Results</h2>';
            if (empty($results)) {
                echo '<p>No suspicious code found.</p>';
            } else {
                echo '<table><tr><th>File</th><th>Matched Content</th></tr>';
                foreach ($results as $row) {
                    echo '<tr><td>' . esc_html($row['file']) . '</td><td><code>' . esc_html($row['match']) . '</code></td></tr>';
                }
                echo '</table>';
            }
            echo '</div>';
        }

        echo '</div></div>';
    }

    private function scan_files($dir, $filenames, $snippets) {
        $results = [];
        $items = @scandir($dir);
        if (!$items) return $results;

        foreach ($items as $item) {
            if ($item === '.' || $item === '..') continue;
            $path = $dir . DIRECTORY_SEPARATOR . $item;

            if (is_dir($path)) {
                $results = array_merge($results, $this->scan_files($path, $filenames, $snippets));
            } else {
                // Filename check
                foreach ($filenames as $f) {
                    if (stripos($item, $f) !== false) {
                        $results[] = ['file' => $path, 'match' => "Filename match: $f"];
                    }
                }
                // Code snippet check
                $contents = @file_get_contents($path);
                if ($contents) {
                    foreach ($snippets as $s) {
                        if (stripos($contents, $s) !== false) {
                            $results[] = ['file' => $path, 'match' => $s];
                        }
                    }
                }
            }
        }
        return $results;
    }
}

new ChucksCodeCruncher();
?>
